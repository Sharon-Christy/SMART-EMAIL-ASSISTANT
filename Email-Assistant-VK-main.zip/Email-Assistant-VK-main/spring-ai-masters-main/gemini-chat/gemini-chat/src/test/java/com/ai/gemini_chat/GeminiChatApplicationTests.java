package com.ai.gemini_chat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeminiChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
